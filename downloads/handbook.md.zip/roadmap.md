# Roadmap

These are directions, not committed dates. Priorities follow user feedback and
confirmed defects. Stable `1.6.0` is already published and publicly verified;
completed work belongs in [release history](history.md), not this list.

## Now

- Process external stable `1.6.0` feedback through the
  [OpenSpec work plan](https://github.com/wa-pis/agent-paranoid-android/tree/main/openspec/changes/external-feedback-1-6):
  reviewed numeric CSV profiling, authenticated Trino access, relational planning
  and utility evidence, bounded statistics and actionable CLI diagnostics.
  Preserve conservative privacy defaults and read-only database budgets. Start
  with reproduced failures; do not reopen corrected historical harness findings.

- Improve onboarding and task-oriented documentation, including versioned and
  downloadable guides.
- Run product-validation pilots on development and analytics workflows.
- Address confirmed client defects, migration feedback and dependency maintenance.
- Monitor source/output consistency, portable business rules and MCP permissions.

## Next

- Design batch-based validation of CSV, JSON and Parquet so complete datasets
  need not remain in memory. Bound cross-table key and uniqueness checks,
  preserve deterministic results and measure memory on synthetic fixtures.
  A separate OpenSpec change is required before implementation.
- Simplify CSV and database workflows using pilot feedback.
- Publish runnable examples and short case studies using synthetic fixtures.
- Improve diagnostics where users repeatedly need help.

## Later

- Add integrations only after demonstrated demand.
- Consider reporting and validation adapters for concrete workflows.
- Evolve public contracts through the compatibility and deprecation policy.

The finite fictional transformation/session campaign for stable `1.6.0`
completed with [explicit coverage limits](release-evidence-1.6.0.md).
That grants no dataset permission. Changed public activation still requires
matching specifications, executable evidence and independent exact-source review.
